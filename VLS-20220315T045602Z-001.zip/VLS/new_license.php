<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Application Form</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
    </head>
    <body >
        <div class="container">
            <div id="form-main">
                <div id="form-div">
                    <form action="database/new_license.php" method="post" enctype="multipart/form-data" class="montform" >
                    <input name="license" type="text" class="feedback-input" required placeholder="Learner's License Number" id="learners_license" required="required" />
                     <input name="dob" type="date" required class="feedback-input" id="dob" placeholder="dd-mm-yyyy" required="required" />
                     <input name="email" type="email" required class="feedback-input" id="email" placeholder="Email" required="required" />
                     <input type="submit" class="button-blue" value="Submit" name="submit"/> 
                    </form>
                    
                </div>
            </div>
        </div>
    </body>
</html>