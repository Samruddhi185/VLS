<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Application Form</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
    </head>
    <body >
        <div class="container">
            <div id="form-main">
                <div id="form-div">
                    <form action="database/learners_license_database.php" method="post" enctype="multipart/form-data" class="montform" >
                        <input name="name" type="text" class="feedback-input" required placeholder="Name" id="name" required="required" />
                         <input name="address" type="text" required class="feedback-input" id="address" placeholder="Address" required="required" />
                         <input name="dob" type="date" required class="feedback-input" id="dob" placeholder="dd-mm-yyyy" required="required" />
                        <input name="contact" type="text" required class="feedback-input" id="contact" placeholder="Contact" required="required" />
                        <input name="email" type="email" required class="feedback-input" id="email" placeholder="Email" required="required" />
                        <input name="photo" type="file" id="file" class="feedback-input" multiple="multiple">
                        <input name="adhar" type="file" id="photo" class="feedback-input">
                        <input name="pan" type="file" id="signature" class="feedback-input" >
                     <input type="submit" class="button-blue" name="submit" value="Submit"/>
                    
                    
                    </form>
                    <!--<form class="montform" id="reused_form" method="post" action="choice.php" enctype="multipart/form-data"; >
                        <!--<p class="name">
                            <input name="name" type="text" class="feedback-input" required placeholder="Name" id="name" required="required" />
                        </p>
                        <p class="dob">
                            <input name="dob" type="date" required class="feedback-input" id="dob" placeholder="dd-mm-yyyy" required="required" />
                        </p>
                        <p class="address">
                            <input name="address" type="text" required class="feedback-input" id="address" placeholder="Address" required="required" />
                        </p>
                        <p class="Contact">
                            <input name="contact" type="text" required class="feedback-input" id="contact" placeholder="Contact" required="required" />
                        </p>
                        <p class="email">
                            <input name="email" type="email" required class="feedback-input" id="email" placeholder="Email" required="required" />
                        </p>
                        
                        <!---<p class="file">
                            <input name="photo" type="file" id="file" class="feedback-input" multiple="multiple">
                        </p>
                        <p class="photo">
                            <input name="adhar" type="file" id="photo" class="feedback-input">
                        </p>
                        <p class="signature">
                            <input name="pan" type="file" id="signature" class="feedback-input" >
                        </p>
                        
                            <input type="submit" class="button-blue" name="submit" value="Submit"/>
                            
                    </form>-->
                    
                </div>
            </div>
        </div>
    </body>
</html>