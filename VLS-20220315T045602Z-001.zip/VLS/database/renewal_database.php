 <?php 
	  
	  use PHPMailer\PHPMailer\PHPMailer;

    require 'vendor/autoload.php';
	   include 'check.php';
	  
	   
      	
	if(! $conn ) {
			die('Could not connect: ' . mysqli_error());
            echo"no connection";
					}
			
		 if(isset($_POST['submit'])){
           // $Name=mysqli_real_escape_string($conn,$_POST['Name']); 
             $license=mysqli_real_escape_string($conn,$_POST['license']);
             $dob=mysqli_real_escape_string($conn,$_POST['dob']);
             $a_date=mysqli_real_escape_string($conn,$_POST['app']);
             $e_date=mysqli_real_escape_string($conn,$_POST['exp']);
             $email=mysqli_real_escape_string($conn,$_POST['email']);
             $scan=addslashes(file_get_contents($_FILES["scan"]["tmp_name"]));
             
             $sql = "UPDATE `learners_license` SET scan_license='$scan',`status`='Renewal_not_visited',app_date='$a_date',exp_date='$e_date' WHERE email='".$email."'";
             $result = mysqli_query($conn, $sql);
             if(! $result ) {
					die('Could not get data: ' . mysqli_error($conn));}
		  $mail = new PHPMailer();

    $mail->isSMTP();                        // set mailer to use SMTP
    $mail->Host = "	smtp.gmail.com";  // specify main and backup server
    $mail->Port = "465";
    $mail->SMTPSecure = "ssl";
    $mail->SMTPAuth = true;     // turn on SMTP authentication
    $mail->Username = "	";  // SMTP username
    $mail->Password = ""; // SMTP password	
    $mail->From = "bhuvadevangi9@gmail.com";
    $mail->FromName = "System-Ad";
    $mail->AddAddress($email);                              // set word wrap to 50 characters
    $mail->IsHTML(true);                                  // set email format to HTML (true) or plain text (false)
    $mail->Subject = "Confirmation Email to visit RTO for Renewal of License";
    $mail->Body    = "blah blah blah";
    $mail->AltBody = "This is the body in plain text for non-HTML mail clients";    
   
    if(!$mail->Send())
    {
       echo "Message could not be sent. <p>";
       echo "Mailer Error: " . $mail->ErrorInfo;
       exit;
    }
   else{
    echo "Message has been sent";
}
    
         }
		

 $conn -> close();
?>
