<?php
include 'conn.php';
 
$conn = OpenCon();
 

 
?>