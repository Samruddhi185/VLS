<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Application Form</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
    </head>
    <body >
        <div class="container">
            <div id="form-main">
                <div id="form-div">
                    <form action="database/renewal_database.php" method="post" enctype="multipart/form-data" class="montform" >
                    <input name="license" type="text" class="feedback-input" required placeholder="License Number" id="learners_license" required="required" />
                        <h3>Date of Birth</h3>
                    <input name="dob" type="date" required class="feedback-input" id="dob" required="required" />
                        <h3>Approval date</h3>
                       
                            <input name="app" type="date" required class="feedback-input" id="dob" placeholder="Approval Date" required="required" />
                     <h3>Expiry Date</h3>
                       
                            <input name="exp" type="date" required class="feedback-input" id="dob" placeholder="Expiry Date" required="required" />
                        <input name="email" type="email" required class="feedback-input" id="email" placeholder="Email" required="required" />
                         <input name="scan" type="file" id="file" class="feedback-input" multiple="multiple">
                         <input type="submit"  class="button-blue" name="submit" value="Submit"/>
                            
                    </form>
                    <!--<form class="montform" action="database/renewal_database.php" id="reused_form" enctype="multipart/form-data" method="post" >
                      
                            <input name="license" type="text" class="feedback-input" required placeholder="License Number" id="learners_license" required="required" />
                      
                        <!--<p class="name">
                            <input name="name" type="text" class="feedback-input" required placeholder="Name" id="name" required="required" />
                        </p>
                        <h3>Date of Birth</h3>
                      
                            <input name="dob" type="date" required class="feedback-input" id="dob" required="required" />
                       
                        <h3>Approval date</h3>
                       
                            <input name="app" type="date" required class="feedback-input" id="dob" placeholder="Approval Date" required="required" />
                     
                        <h3>Expiry Date</h3>
                       
                            <input name="exp" type="date" required class="feedback-input" id="dob" placeholder="Expiry Date" required="required" />
                     
                        <!--<p class="address">
                            <input name="address" type="text" required class="feedback-input" id="address" placeholder="Address" required="required" />
                        </p>
                        <p class="Contact">
                            <input name="contact" type="text" required class="feedback-input" id="contact" placeholder="Contact" required="required" />
                        </p>
                        
                            <input name="email" type="email" required class="feedback-input" id="email" placeholder="Email" required="required" />
                      
                        
                        <!--<p class="file">
                            <input name="image" type="file" id="file" class="feedback-input" multiple="multiple">
                        </p>
                        <p class="photo">
                            <input name="image" type="file" id="photo" class="feedback-input">
                        </p>
                        <h3>Scanned License</h3>
                        
                            <input name="scan" type="file" id="file" class="feedback-input"/ >
                      
                        
                            <input type="submit"  class="button-blue" name="submit" value="Submit"/>
                            
                    </form>-->
                    
                </div>
            </div>
        </div>
    </body>
</html>