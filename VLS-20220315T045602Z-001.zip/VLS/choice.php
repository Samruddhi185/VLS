<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Application Form</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
    </head>
    <body >
        <div class="container">
            <div id="form-main">
                <div id="form-div">
                    <form class="montform" id="reused_form" enctype=&quot;multipart/form-data&quot; >
                       <a href="new_license.php"><h4>REGISTER HERE FOR NEW LICENSE</h4></a>
                        <a href="renewal.php"><h4>REGISTER HERE FOR RENEWAL LICENSE</h4></a>
                        <a href="learners_license.php"><h4>REGISTER HERE FOR LEARNING LICENSE</h4></a>
                    </form>
                    
                   
                </div>
            </div>
        </div>
    </body>
</html>