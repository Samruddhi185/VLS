using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VLS.VLSClasses;

// This is the code for your desktop app.
// Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.

namespace VLS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox5.PasswordChar = '*';
            textBox5.MaxLength = 10;
            textBox2.MaxLength = 10;
            textBox_pass.PasswordChar = '*';
            textBox_pass.MaxLength = 10;

        }

        Login login = new Login();
        Register register = new Register();

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Click on the link below to continue learning how to build a desktop app using WinForms!
            System.Diagnostics.Process.Start("http://aka.ms/dotnet-get-started-desktop");

        }

        private void button1_Click(object sender, EventArgs e)
        {

            register.oid_register = int.Parse(textBox4.Text);
            register.oname_register = textBox3.Text;
            register.contact_register = int.Parse(textBox2.Text);
            register.address_register = textBox1.Text;
            register.password_register = (textBox5.Text).GetHashCode();
            

            bool success = register.Insert(register);
            if (success)
            {
                MessageBox.Show("Successful registration.");
            }
            else
            {
                MessageBox.Show("Unsuccessful registation. Please register again!");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            login.OfficerID = int.Parse(textBox_oid.Text);
            login.Password = (textBox_pass.Text).GetHashCode(); ;

            int success = login.Check(login);
            if(success==1)
            {
                MessageBox.Show("Successful Login.");
               
                AfterLogin afterLogin = new AfterLogin();
                afterLogin.Show();
                this.Hide();
            }
            else if(success == 2)
            {
                MessageBox.Show("Wrong password.");
            }
            else
            {
                MessageBox.Show("No such user exists.");
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void helloWorldLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
