namespace VLS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.debugInstructionsLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.helloWorldLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_oid = new System.Windows.Forms.TextBox();
            this.textBox_pass = new System.Windows.Forms.TextBox();
            this.login_button = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.address_register = new System.Windows.Forms.Label();
            this.contact_register = new System.Windows.Forms.Label();
            this.oname_register = new System.Windows.Forms.Label();
            this.oid_register = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.password_register = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // debugInstructionsLabel
            // 
            this.debugInstructionsLabel.AutoSize = true;
            this.debugInstructionsLabel.Location = new System.Drawing.Point(44, 500);
            this.debugInstructionsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.debugInstructionsLabel.Name = "debugInstructionsLabel";
            this.debugInstructionsLabel.Size = new System.Drawing.Size(311, 27);
            this.debugInstructionsLabel.TabIndex = 1;
            this.debugInstructionsLabel.Text = "New Employee? Register here.";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.Location = new System.Drawing.Point(375, 492);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 50);
            this.button1.TabIndex = 2;
            this.button1.Text = "Register";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // helloWorldLabel
            // 
            this.helloWorldLabel.AutoSize = true;
            this.helloWorldLabel.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helloWorldLabel.ForeColor = System.Drawing.SystemColors.Highlight;
            this.helloWorldLabel.Location = new System.Drawing.Point(219, 9);
            this.helloWorldLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.helloWorldLabel.Name = "helloWorldLabel";
            this.helloWorldLabel.Size = new System.Drawing.Size(623, 79);
            this.helloWorldLabel.TabIndex = 3;
            this.helloWorldLabel.Text = "Vehicle Licensing System";
            this.helloWorldLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.helloWorldLabel.Click += new System.EventHandler(this.helloWorldLabel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(611, 117);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 27);
            this.label1.TabIndex = 4;
            this.label1.Text = "Officer ID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(614, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 27);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password";
            // 
            // textBox_oid
            // 
            this.textBox_oid.Location = new System.Drawing.Point(777, 117);
            this.textBox_oid.Name = "textBox_oid";
            this.textBox_oid.Size = new System.Drawing.Size(100, 34);
            this.textBox_oid.TabIndex = 6;
            // 
            // textBox_pass
            // 
            this.textBox_pass.Location = new System.Drawing.Point(777, 186);
            this.textBox_pass.Name = "textBox_pass";
            this.textBox_pass.Size = new System.Drawing.Size(100, 34);
            this.textBox_pass.TabIndex = 7;
            // 
            // login_button
            // 
            this.login_button.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.login_button.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.login_button.Location = new System.Drawing.Point(767, 269);
            this.login_button.Name = "login_button";
            this.login_button.Size = new System.Drawing.Size(121, 54);
            this.login_button.TabIndex = 8;
            this.login_button.Text = "Login";
            this.login_button.UseVisualStyleBackColor = false;
            this.login_button.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(233, 337);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 34);
            this.textBox1.TabIndex = 9;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(233, 269);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 34);
            this.textBox2.TabIndex = 10;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(233, 193);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 34);
            this.textBox3.TabIndex = 11;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(233, 110);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 34);
            this.textBox4.TabIndex = 12;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // address_register
            // 
            this.address_register.AutoSize = true;
            this.address_register.Location = new System.Drawing.Point(64, 337);
            this.address_register.Name = "address_register";
            this.address_register.Size = new System.Drawing.Size(89, 27);
            this.address_register.TabIndex = 13;
            this.address_register.Text = "Address";
            // 
            // contact_register
            // 
            this.contact_register.AutoSize = true;
            this.contact_register.Location = new System.Drawing.Point(64, 269);
            this.contact_register.Name = "contact_register";
            this.contact_register.Size = new System.Drawing.Size(85, 27);
            this.contact_register.TabIndex = 14;
            this.contact_register.Text = "Contact";
            // 
            // oname_register
            // 
            this.oname_register.AutoSize = true;
            this.oname_register.Location = new System.Drawing.Point(64, 193);
            this.oname_register.Name = "oname_register";
            this.oname_register.Size = new System.Drawing.Size(141, 27);
            this.oname_register.TabIndex = 15;
            this.oname_register.Text = "Officer Name";
            // 
            // oid_register
            // 
            this.oid_register.AutoSize = true;
            this.oid_register.Location = new System.Drawing.Point(64, 113);
            this.oid_register.Name = "oid_register";
            this.oid_register.Size = new System.Drawing.Size(107, 27);
            this.oid_register.TabIndex = 16;
            this.oid_register.Text = "Officer ID";
            this.oid_register.Click += new System.EventHandler(this.label6_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(233, 408);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 34);
            this.textBox5.TabIndex = 17;
            // 
            // password_register
            // 
            this.password_register.AutoSize = true;
            this.password_register.Location = new System.Drawing.Point(64, 411);
            this.password_register.Name = "password_register";
            this.password_register.Size = new System.Drawing.Size(104, 27);
            this.password_register.TabIndex = 18;
            this.password_register.Text = "Password";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 27F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 616);
            this.Controls.Add(this.password_register);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.oid_register);
            this.Controls.Add(this.oname_register);
            this.Controls.Add(this.contact_register);
            this.Controls.Add(this.address_register);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.login_button);
            this.Controls.Add(this.textBox_pass);
            this.Controls.Add(this.textBox_oid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.helloWorldLabel);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.debugInstructionsLabel);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "VLS-Login Page";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label debugInstructionsLabel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label helloWorldLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_oid;
        private System.Windows.Forms.TextBox textBox_pass;
        private System.Windows.Forms.Button login_button;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label address_register;
        private System.Windows.Forms.Label contact_register;
        private System.Windows.Forms.Label oname_register;
        private System.Windows.Forms.Label oid_register;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label password_register;
    }
}

