﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
namespace VLS
{
    public partial class AfterLogin : Form
    {
        public static int appointment_no;

        static string conn = "datasource = localhost; username = root; password =; database = VLS; SslMode = none";
        public AfterLogin()
        {
            InitializeComponent();
        }

        private void AfterLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void button_aid_Click(object sender, EventArgs e)
        {
            appointment_no = int.Parse(textBox_aid.Text);
            try
            {
                MySqlConnection mySqlConnection = new MySqlConnection(conn);
                mySqlConnection.Open();

                string query = "select * from learners_license where app_id = @appointment_no;";


                MySqlCommand mySqlCommand = new MySqlCommand(query, mySqlConnection);
                mySqlCommand.Parameters.AddWithValue("@appointment_no", appointment_no);

                MySqlDataReader sqlDataReader;

                sqlDataReader = mySqlCommand.ExecuteReader();
                //flag = 0;
                while (sqlDataReader.Read())
                {
                    string k = "APPLICATION ID:" + sqlDataReader.GetValue(0) + "\n\nLICENSE NO:" + sqlDataReader.GetValue(1) + "\n\nNAME:" + sqlDataReader.GetValue(2)
                        + "\n\nDATE OF BIRTH:" + sqlDataReader.GetValue(3) + "\n\nEMAIL ID:" + sqlDataReader.GetValue(4)
                        + "\n\nSTATUS:" + sqlDataReader.GetValue(10) + "\n\nAPPLICATION DATE:" + sqlDataReader.GetValue(11) + "\n\nEXPIRY DATE:" + sqlDataReader.GetValue(12);
                    MessageBox.Show(k);


                }
                string query2 = "select * from learners_license where app_id = '" + appointment_no + "';";
                sqlDataReader.Close();
                MySqlCommand mscmd = new MySqlCommand(query2, mySqlConnection);

                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(mscmd);

                da.Fill(dt);

                byte[] img1 = (byte[])dt.Rows[0][6];

                MemoryStream ms = new MemoryStream(img1);
                pictureBox1.Image = Image.FromStream(ms);

                byte[] img2 = (byte[])dt.Rows[0][7];

                MemoryStream ms2 = new MemoryStream(img2);
                pictureBox2.Image = Image.FromStream(ms2);

                byte[] img3 = (byte[])dt.Rows[0][8];

                MemoryStream ms3 = new MemoryStream(img3);
                pictureBox3.Image = Image.FromStream(ms3);

                byte[] img4 = (byte[])dt.Rows[0][9];

                MemoryStream ms4 = new MemoryStream(img4);
                pictureBox4.Image = Image.FromStream(ms4);

                da.Dispose();

            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }


        }

        private void button_R_Click(object sender, EventArgs e)
        {
            bool isSuccess = false;
            string start_date = textBox_sd.Text;
            string expiry_date = textBox_ed.Text;

            MySqlConnection connection = new MySqlConnection(conn);
            try
            {
                string executed = "license_renewed";
                
                //app_date = @start_date, exp_date =  @expiry_date
                string query = "update learners_license SET status = '"+executed+ "', app_date = '" + start_date + "', exp_date = '" + expiry_date + "'  WHERE app_id = '" + appointment_no+"';";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                //cmd.Parameters.AddWithValue("@status", "hello");
                //cmd.Parameters.AddWithValue("@start_date", start_date);
                //cmd.Parameters.AddWithValue("@expiry_date", expiry_date);
                //cmd.Parameters.AddWithValue("@appointment_no", appointment_no);

                connection.Open();

                mySqlDataAdapter.UpdateCommand = new MySqlCommand(query, connection);

                mySqlDataAdapter.UpdateCommand.ExecuteNonQuery();
                isSuccess = true;
                if (isSuccess)
                {
                    MessageBox.Show("Renewal granted.");
                }
                else
                {
                    MessageBox.Show("Renewal failed.");
                }
                
            }
            catch (Exception exc)
            {
                isSuccess = false;
                System.Windows.Forms.MessageBox.Show(exc.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button_N_Click(object sender, EventArgs e)
        {
            bool isSuccess = false;
            string start_date = textBox_sd.Text;
            string expiry_date = textBox_ed.Text;

            MySqlConnection connection = new MySqlConnection(conn);
            try
            {
                string executed = "license_granted";
                int lno = 45629;

                //app_date = @start_date, exp_date =  @expiry_date
                string query = "update learners_license SET License_number = '" + lno + "', status = '" + executed + "', app_date = '" + start_date + "', exp_date = '" + expiry_date + "'  WHERE app_id = '" + appointment_no + "';";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                //cmd.Parameters.AddWithValue("@status", "hello");
                //cmd.Parameters.AddWithValue("@start_date", start_date);
                //cmd.Parameters.AddWithValue("@expiry_date", expiry_date);
                //cmd.Parameters.AddWithValue("@appointment_no", appointment_no);

                connection.Open();

                mySqlDataAdapter.UpdateCommand = new MySqlCommand(query, connection);

                mySqlDataAdapter.UpdateCommand.ExecuteNonQuery();
                isSuccess = true;
                if (isSuccess)
                {
                    MessageBox.Show("New license granted.");
                }
                else
                {
                    MessageBox.Show("New license failed.");
                }

            }
            catch (Exception exc)
            {
                isSuccess = false;
                System.Windows.Forms.MessageBox.Show(exc.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void button_L_Click(object sender, EventArgs e)
        {
            bool isSuccess = false;
            string start_date = textBox_sd.Text;
            string expiry_date = textBox_ed.Text;

            MySqlConnection connection = new MySqlConnection(conn);
            try
            {
                string executed = "learners_visited";
                int lno = 45629;

                //app_date = @start_date, exp_date =  @expiry_date
                string query = "update learners_license SET status = '" + executed + "'  WHERE app_id = '" + appointment_no + "';";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataAdapter mySqlDataAdapter = new MySqlDataAdapter();
                //cmd.Parameters.AddWithValue("@status", "hello");
                //cmd.Parameters.AddWithValue("@start_date", start_date);
                //cmd.Parameters.AddWithValue("@expiry_date", expiry_date);
                //cmd.Parameters.AddWithValue("@appointment_no", appointment_no);

                connection.Open();

                mySqlDataAdapter.UpdateCommand = new MySqlCommand(query, connection);

                mySqlDataAdapter.UpdateCommand.ExecuteNonQuery();
                isSuccess = true;
                if (isSuccess)
                {
                    MessageBox.Show("Learners test passed.");
                }
                else
                {
                    MessageBox.Show("Learners test failed.");
                }

            }
            catch (Exception exc)
            {
                isSuccess = false;
                System.Windows.Forms.MessageBox.Show(exc.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
