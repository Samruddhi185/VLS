﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace VLS.VLSClasses
{
    class Login
    {
        //getter setter properties - acts as data carrier
        public int OfficerID;
        public int Password;
        public int flag;
        // flag = 0 if user  not found
        // flag = 1 if user found and password correct
        // f;ag = 2 if user found but password not correct

        //static string conn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;


        static string conn = "datasource = localhost; username = root; password =; database = VLS; SslMode = none";
        //MySqlConnection mySqlConnection = new MySqlConnection(conn);
        public int Check(Login login)
        {
            OfficerID = login.OfficerID;
            Password = login.Password;
           // System.Windows.Forms.MessageBox.Show(""+OfficerID);
            MySqlConnection connection = new MySqlConnection(conn);
            DataTable dt = new DataTable();
            try
            {

                connection.Open();
                string query = "SELECT * FROM Officer;";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                MySqlDataReader sqlDataReader;

                sqlDataReader = cmd.ExecuteReader();
                flag = 0; 
                while(sqlDataReader.Read())
                {
                    //string x = (string)(sqlDataReader.GetValue(0));
                    string x = ""+sqlDataReader.GetValue(0);
                    int y = int.Parse(x);
                    if(y==OfficerID)
                    {
                        flag = 2;
                        string k = ""+sqlDataReader.GetValue(4);
                        int l = int.Parse(k);
                        if(l == Password)
                        {
                            flag = 1;
                        }
                    }
                }



            }
            catch(Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }
            finally
            {
                connection.Close();
            }
            return flag;
        }

        
    }
}
