﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace VLS.VLSClasses
{
    class Register
    {
        public int oid_register { get; set; }
        public string oname_register { get; set; }
        public int contact_register { get; set; }
        public string address_register { get; set; }
        public int password_register { get; set; }

        // static string conn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;

        static string conn = "datasource = localhost; username = root; password =; database = VLS; SslMode = none";
        public bool Insert(Register rr)
        {
            bool isSuccess = false;
            MySqlConnection connection = new MySqlConnection(conn);
            try
            {
                string query = "INSERT INTO officer VALUES(@oid_register, @oname_register, @contact_register, @address_register, @password_register);";
                MySqlCommand cmd = new MySqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@oid_register",rr.oid_register);
                cmd.Parameters.AddWithValue("@oname_register", rr.oname_register);
                cmd.Parameters.AddWithValue("@contact_register", rr.contact_register);
                cmd.Parameters.AddWithValue("@address_register", rr.address_register);
                cmd.Parameters.AddWithValue("@password_register", rr.password_register);

                connection.Open();

                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
            }
            finally
            {
                connection.Close();
            }
            return isSuccess;
        }
    }
}
